-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 192.168.0.11    Database: obbang
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event` (
  `event_eno` int NOT NULL AUTO_INCREMENT,
  `event_title` varchar(200) NOT NULL,
  `event_content` varchar(1000) DEFAULT '내용없음',
  `event_regdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `event_image` longtext,
  PRIMARY KEY (`event_eno`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES (47,'순금 총 35돈! 황금 열쇠의 주인공은?','이벤트기간 2023-4-26 ~ 2023-5-24','2023-04-28 00:54:17','3adfac53-a1f2-4bf1-98b8-8ca5345f950b_2023426155664921.jpg'),(48,'KT 맴버쉽 VVIP/VIP 혜택','이벤트 기간 2023-04-03 ~ 2023-12-31','2023-04-28 00:58:31','de69d64c-68df-4d17-9622-df98ae4790f6_20234314123195573.jpg'),(49,'네이버페이 포인트머니로 결제시 6천원 적립','이벤트 기간 2023-04-17 ~ 2023-05-07','2023-04-28 01:01:04','523fb53b-6900-4e21-877a-e7da839f5b9e_20234178253443929.jpg'),(50,'애플페이','이벤트 기간 2023-04-20 ~ 2023-07-31','2023-04-28 01:03:03','e001cbde-1a1d-45cf-91fc-3c3489eea46b_20234208392675831.jpg'),(51,'알쏭달쏭 캐치! 티니핑과 매일매일 파티타임','이벤트 기간 2023-03-28 ~ 2023-04-30','2023-04-28 01:06:22','b5bf90f8-ba98-4d98-8b77-c1317c71ae8c_202332811401248630.jpg'),(52,'CJ 옴니서비스 약관 동의 이벤트','이벤트 기간 2023-04-13 ~ 2023-04-30','2023-04-28 01:09:49','48837c53-21da-42a5-9a23-e5bb966161bb_202341315585291799.jpg'),(53,'현대카드 매일 50% M포인트 사용 가능','이벤트 기간 2023-12-30 ~ 2023-12-31','2023-04-28 01:10:11','4a80e589-dc6c-4ca7-9aee-d5c74495bf26_202212308414317269.jpg'),(54,'5월, 꽃길을 선물할게요','이벤트 기간 2023-04-24 ~ 2023-04-30','2023-04-28 01:14:18','3143120f-18a2-4ede-a9f1-16ac9583f750_202342416235378985.jpg'),(55,'파리바게뜨 인기 캐릭터케이크 5,000원 혜택!?','이벤트기간 2023-04-20 ~ 2023-04-30','2023-04-28 01:16:58','480c3ab0-24a0-44c8-a0f2-35e122933008_벨리곰-썸네일-600x600.jpg'),(56,' 오미자에이드 한정특가❤️ READ MORE 진행 중 GREENS, GRAINS, GREAT! 파리바게뜨 그린페어?','이벤트 기간 2023-04-20 ~ 2023-05-10','2023-04-28 01:32:14','a1f6aec0-735d-4bb2-b922-ab5dce9af0d0_프로모션_썸네일_1000_1000-600x600.jpg'),(57,'4월의 제품 인생크림빵 4종','이벤트기간 2023-04-01 ~ 2023-04-30','2023-04-28 01:33:15','24dd6d7d-95e6-4720-b531-fa720fa4df52_4월의-제품_인생크림빵-4종_썸네일_230417-600x600.jpg'),(58,'파바와 크래프트 하인즈 크림치즈의 만남!?','이벤트 기간 2023-04-20 ~ 2023-05-30','2023-04-28 01:40:37','b70114ce-b459-466c-8352-b0276fbf7733_썸네일-1-600x600.jpg');
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-21 12:50:07
