-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 192.168.0.11    Database: obbang
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `Notice_nno` int NOT NULL AUTO_INCREMENT,
  `Notice_title` varchar(150) DEFAULT NULL,
  `Notice_content` varchar(2000) DEFAULT NULL,
  `Notice_writer` varchar(50) DEFAULT NULL,
  `Notice_regdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `Notice_image` longtext,
  PRIMARY KEY (`Notice_nno`)
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (154,'CJ ONE 멤버십 서비스 정책 변경 안내','CJ ONE 멤버십 서비스 정책 변경 안내\r\n항상 저희 뚜레쥬르를 사랑해 주시는 고객 여러분께 감사의 말씀 드립니다.\r\n뚜레쥬르의 CJ ONE 멤버십 서비스 변경사항이 있어 아래와 같이 안내 드립니다.\r\n\r\n1. 변경 내용 : CJ ONE 멤버십 적립률 변경\r\n[기존] 5% 적립 (뚜레쥬르 온라인 쇼핑몰 1% 적립, 제휴/할인시 0.5% 적립)\r\n[변경] 0.5% 적립 (뚜레쥬르 온라인 쇼핑몰 0.5% 적립, 제휴/할인시 0.1% 적립)\r\n\r\n2. 변경 적용 일시 : 2018년 3월 1일 (목)\r\n\r\n앞으로 더 좋은 서비스를 위해 노력하겠습니다.\r\n\r\n뚜레쥬르 적립률 변경과 관련한 문의사항은 아래 고객센터로 문의 주시기 바랍니다.\r\n* CJ푸드빌 고객센터 : 1577-0700\r\n\r\n감사합니다.','관리자','2023-04-28 01:50:35',NULL),(155,'뚜레쥬르 모바일 제품 교환권 이용 안내','뚜레쥬르 모바일 제품 교환권 이용 안내\r\n\r\n뚜레쥬르를 이용해 주시는 모든 고객분들께 감사 드리며\r\n보유하고 계신 \"뚜레쥬르 모바일 제품 교환권\" 사용 시 하기 내용 숙지 하시어 이용 부탁 드립니다.\r\n[이용 안내]\r\n\r\n1. 뚜레쥬르 모바일 제품 교환권은 매장 별 판매 가격이 상이 할 수 있기에 일부 매장에서는 추가 금액 결제 후 교환이 가능 합니다.\r\n\r\n2. 뚜레쥬르 모바일 제품 교환권은 매장내 동일 제품이 없을 경우 동일 가격 내 타 제품으로 교환이 가능 합니다.\r\n\r\n3. 뚜레쥬르 모바일 제품 교환권을 매장에서 현금으로 교환할 수 없습니다.\r\n\r\n4. 뚜레쥬르 모바일 제품 교환권 사용 시 쿠폰 금액에 한해 제휴 할인 및 포인트 적립이 불가 합니다.\r\n\r\n5. 뚜레쥬르 모바일 제품 교환권 내 기재 된 금액 외 추가 결제분에 한해 제휴 할인 및 포인트 적립이 가능 합니다.\r\n\r\n6. 뚜레쥬르 모바일 제품 교환권 사용 시 타 행사와 중복 적용이 불가 합니다.\r\n\r\n7. 휴게소, 인천 공항 등 일부 특수 매장은 뚜레쥬르 모바일 제품 교환권 사용이 불가 합니다.\r\n\r\n감사합니다.','관리자','2023-04-28 01:51:28',NULL),(156,'뚜레쥬르 월간 구독 서비스 안내','최고의 혜택을 경험하는\r\n월간 구독 서비스\r\n지금 신청하세요\r\n\r\n뚜레쥬르만의 차별화된 그랑드 카페 스페셜티 COFFEE\r\n매일 700원으로 즐기는 커피 구독권 19,900원\r\n1일 1잔/아메리카노 限(HOT, ICE)/R size\r\n\r\n매일 매일 속 편하고 맛있게 즐기는 고품격 프리미엄 식빵\r\n매주 즐기는 프리미엄 식빵 구독권 7,900원\r\n주 1회/프리미엄 식빵류 1종 선택\r\n\r\n스페셜티 커피와 재료부터 다른 샌드위치로 하루 아침의 건강을 챙기는 모닝세트\r\n건강한 아침을 챙기는 모닝세트 구독권 49,500원\r\n1일 1회/커피+모닝 샌드위치/07:00~10:00/주말 제외','관리자','2023-04-28 01:54:39',NULL),(157,'2023 서울 카페&베이커리페어 참가사 조기신청 마감 임박!','2023 서울 카페&베이커리페어\r\n\r\n참가사를 모집합니다.\r\n⠀\r\n12월 23일(금)까지 조기신청 모집 중이니\r\n신청을 서둘러 주세요.\r\n⠀\r\n온라인으로 참가신청해 주시면 사무국에서 검토 후 연락드립니다.\r\n⠀\r\n온라인 참가 안내\r\nwww.cafenbakeryfair.com/page/page2\r\n\r\n온라인 참가신청 바로가기\r\nwww.cafenbakeryfair.com/myreg/st_myreg\r\n⠀\r\n참가문의 02-2238-0346-7','관리자','2023-04-28 02:05:53',NULL),(158,'[안내] 일반인 사전등록 입장안내','안녕하세요? 서카베입니다.\r\n⠀\r\n2023 서울 카페&베이커리페어와 함께\r\n커피/디저트/베이커리/카페창업·운영의\r\n모든 것을 시작해 보세요.\r\n⠀\r\n무료입장 신청하기\r\nwww.cafenbakeryfair.com/page/page18\r\n⠀\r\n▣2023년 1월 31일(화)까지 사전등록 시\r\n→ 무료입장\r\n⠀\r\n▣2023년 2월 1일(수)부터 3월 1일(수)까지 사전등록 시\r\n→ 6,000원(60% 할인)\r\n⠀\r\n※ 서카베는 사전등록한 본인에 한하여 무료입장이 가능합니다.\r\n\r\nURL복사','관리자','2023-04-28 02:06:57',NULL),(159,'2020 카페&베이커리페어 참가업체리스트 공개','안녕하세요? 미래전람입니다. \r\n\r\n2020 카페&베이커리페어 참가업체 리스트가 공개 되었습니다. \r\n\r\n오시기전 미리미 확인 하시고 관람하세요~!\r\n\r\n감사합니다. \r\n\r\n \r\n\r\n업체리스트 보러가기\r\n\r\nhttp://www.cafenbakeryfair.com/myboard/st_lecture','관리자','2023-04-28 05:36:23',NULL),(160,'2023 카베 참가업체리스트 미리 확인하세요~!','2023 카페&베이커리페어 참가업체리스트 미리 확인하세요.\r\n\r\n참가업체 리스트는 계속 업데이트 됩니다~^^\r\n\r\n아래 링크를 클릭해주세요~!\r\n\r\n \r\n\r\n참가업체 미리보기 \r\n\r\n베스트브랜드 미리보기 \r\n\r\n2023 NEW & HOT 브랜드 미리보기 ','관리자','2023-04-28 05:37:56',NULL),(161,'카카오페이 결제 서비스 장애 안내','안녕하세요.\r\n\r\nOBBANG 운영팀입니다.\r\n\r\n \r\n\r\n4/18(화) 카카오페이 결제 장애 관련 안내드립니다.\r\n\r\n \r\n\r\n1. 장애내용 : \'카카오페이\' 결제수단을 이용하여 결제 시 장애 발생\r\n\r\n2. 장애시간 : 2023년 4월 18일(화) 16:39 ~ 17:03\r\n\r\n \r\n\r\n*최종안내\r\n\r\n현재에는 복구 완료 되어 카카오페이 결제 가능합니다. \r\n\r\n추가적인 문제가 있거나, 관련하여 문의사항이 있을 경우 앱 내고객센터를 통해 문의해주시기바랍니다.\r\n\r\n \r\n\r\n이용에 불편을 드려 대단히 죄송합니다.\r\n\r\n \r\n\r\n감사합니다.','관리자','2023-04-28 05:52:15',NULL),(162,'[복구완료]본인 인증 서비스(드림시큐리티) 장애 안내','안녕하세요.\r\n\r\nOBBANG운영팀입니다.\r\n\r\n \r\n\r\n4/14(금) 본인 인증 서비스(드림시큐리티) 장애 관련 안내드립니다.\r\n\r\n \r\n\r\n1. 장애 내용 : 본인 인증 시도 시 오류 발생\r\n\r\n2. 장애시간 : 2023년 4월 14일(금) 14시 03분 ~ 23시 10분경\r\n\r\n \r\n\r\n*최종 안내\r\n\r\n현재에는 복구 완료되어 본인 인증 진행이 가능합니다.\r\n\r\n추가적인 문제가 있거나, 관련하여 문의사항이 있을 경우 앱 내 고객센터를 통해 문의해 주시기 바랍니다.\r\n\r\n \r\n\r\n이용에 불편을 드려 대단히 죄송합니다.\r\n\r\n \r\n\r\n감사합니다.','관리자','2023-04-28 05:53:35',NULL),(163,'구글 인앱 결제 서비스 장애 안내','안녕하세요.\r\n\r\nOBBANG 운영팀입니다.\r\n\r\n \r\n\r\n구글 인앱 결제 장애 관련 안내드립니다.\r\n\r\n \r\n\r\n1. 장애내용 : ‘구글 인앱’ 결제 시 장애 발생(충전 불가)\r\n\r\n2. 장애시간 : 2023년 4월 25일(화), 26(수) 일부 시간 \r\n\r\n \r\n\r\n현재에는 정상 결제 가능합니다.\r\n\r\n \r\n\r\n장애 시간에 발생한 결제 오류건에 대해 확인 중에 있으며\r\n\r\n결제 후 캐시 미지급 건은 4/26(수) 중 취소 처리 예정입니다.\r\n\r\n \r\n\r\n취소 처리 완료 후 본 공지를 통해 추가 안내드리겠습니다.\r\n\r\n \r\n\r\n[추가]\r\n\r\n구글 인앱 결제 장애 관련으로 결제 후 캐시 미지급건에 대해 4/26(수) 19시 10분경 취소 처리 완료되었습니다.\r\n\r\n추가 문의 사항이 있으실 경우 앱 내 고객센터로 문의 부탁드립니다.\r\n\r\n \r\n\r\n이용에 불편을 드려 대단히 죄송합니다.\r\n\r\n감사합니다.','관리자','2023-04-28 05:54:48',NULL),(164,'4월의 제품이벤트','이벤트기간 2023-04-20 ~ 2023-05-10','관리자','2023-05-01 03:46:10','fa21b372-528e-48fb-a3a5-b58842b779fb_4월의-제품_인생크림빵-4종_썸네일_230417-600x600.jpg'),(165,'[공지사항] 파리바게뜨의 상생누리','상생누리','관리자','2023-05-01 07:42:02','29d10094-6163-4462-8190-530134b49414_생생누리-표지-3.jpg');
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-21 12:50:08
