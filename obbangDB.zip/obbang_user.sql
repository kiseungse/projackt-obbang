-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 192.168.0.11    Database: obbang
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_bno` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `user_pw` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_sex` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_phone` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_year` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_month` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_day` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_address1` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_address2` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_address3` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `user_admin` int NOT NULL,
  PRIMARY KEY (`user_bno`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (33,'관리자3','1234','kihyun2233@gmail.com','남자','010-2647-7793','김기현','2023','04','27','02603','서울 동대문구 고미술로 11 (답십리동)','123',1),(34,'관리자1','1234','whgdmsdpseld@naver.com','남자','010-1111-1111','관리자1','2023','04','27','06122','서울 강남구 논현로111길 3 (논현동, 휴먼스페이스주상복합아파트)','aa',1),(35,'관리자4','1234','rltmdtj@naver.com','남자','010-8828-0944','관리자4','2023','04','27','03180','서울 종로구 경교장길 5 (교남동)','obbang주식회사',1),(36,'관리자2','1234','police-112@naver.com','남자','010-5715-0704','관리자2','1992','04','24','03180','서울 종로구 교남동 7 ','2222',1),(37,'user1','1234','dk_0424@naver.com','남자','010-0000-0001','유저1','2023','04','27','03180','서울 종로구 경교장길 5 (교남동)','111-111',0),(38,'user2','1234','dk_0424@naver.com','남자','010-0000-0002','유저2','2023','04','27','03180','서울 종로구 경교장1길 1 (교남동)','2222',1),(39,'member1','1234','asdf@naver.com','남자','010-1111-1111','맴버1','2023','04','28','03180','서울 종로구 경고장길 5(교남동)','2222',0),(40,'member2','1234','asdf@naver.com','남자','010-1111-1111','맴버2','2023','04','28','03180','서울 종로구 경고장길 5(교남동)','2222',0),(41,'member3','1234','asdf@naver.com','남자','010-1111-1111','맴버3','2023','04','28','03180','서울 종로구 경고장길 5(교남동)','2222',0),(42,'member4','1234','asdf@naver.com','남자','010-1111-1111','맴버4','2023','04','28','03180','서울 종로구 경고장길 5(교남동)','2222',0),(44,'member5','1234','asdf@naver.com','남자','010-1111-1111','맴버5','2023','04','28','03180','서울 종로구 경고장길 5(교남동)','2222',0),(45,'user100','111','dk_0424@naver.com','남자','010-0000-0000','기승서','2023','05','02','03180','서울 종로구 경교장길 5 (교남동)','1111',0),(46,'user3','1234','police-112@naver.com','남자','010-1111-1111','김길동','2000','01','01','03180','서울 종로구 경교장길 5 (교남동)','종로 1-1',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-21 12:50:08
