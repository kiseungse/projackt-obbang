-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 192.168.0.11    Database: obbang
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu` (
  `menu_id` int NOT NULL AUTO_INCREMENT,
  `store_store` varchar(50) NOT NULL,
  `menu_menu` varchar(50) NOT NULL,
  `menu_price` int NOT NULL,
  `menu_info` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`menu_id`),
  KEY `menu_ibfk_1_idx` (`store_store`),
  CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`store_store`) REFERENCES `store` (`store_store`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (73,'패스트리부티크','생크림 케이크',68000,NULL),(74,'패스트리부티크','앙금 빵',5200,NULL),(75,'패스트리부티크','트리 케이크',88000,NULL),(79,'성심당','보문산 메아리',6000,NULL),(80,'성심당','튀김소보로',2500,NULL),(81,'성심당','판타롱 부추빵',3000,NULL),(88,'이성당','앙금빵',3000,NULL),(89,'이성당','야채빵',2000,NULL),(90,'런던베이글뮤지엄','Bricklane sandwich',6800,NULL),(91,'런던베이글뮤지엄','Potato cheese bagel',5500,NULL),(92,'이성당','호박앙금패스츄리',4500,NULL),(93,'런던베이글뮤지엄','Salt butter bagel',4700,NULL),(94,'청수당','딸기 수플레카스테라',18800,NULL),(95,'청수당','말차 프로마쥬케이크',14300,NULL),(96,'청수당','흑임자 프로마쥬케이크',14300,NULL),(97,'이디야 커피','아메리카노',3300,NULL),(98,'이디야 커피','카페라떼',4000,NULL),(99,'이디야 커피','토피 카라멜 크림',5100,NULL),(100,'호산빵집','고로케',2000,NULL),(101,'호산빵집','꽈배기',1500,NULL),(102,'호산빵집','호산세트',10000,NULL),(103,'블루보틀','놀라플로트',6300,NULL),(104,'라미스콘','말차 화이트초코칩',3900,NULL),(105,'라미스콘','수플레 치즈 케이크',15800,NULL),(106,'라미스콘','초코칩',3800,NULL),(107,'블루보틀','홈카페 커피',5000,NULL),(108,'블루보틀','시그니처 라떼',5500,NULL),(109,'스타벅스','딸기 아사이 레모네이드',6700,NULL),(110,'스타벅스','리저브 콜드 브루',4800,NULL),(113,'스타벅스','제주 유기농 말차 프라푸치노',5800,NULL),(114,'파리바게뜨','왕크림도넛',2800,NULL),(116,'파리바게뜨','행복마들렌',2400,NULL),(117,'파리바게뜨','정통 에그 타르트',2900,NULL),(118,'삼송빵집','먹물통옥수수빵',2600,NULL),(119,'삼송빵집','크림치즈찰떡빵',3000,NULL),(120,'커피빈','에스프레소더블',3800,NULL),(121,'삼송빵집','통옥수수빵',2500,NULL),(122,'커피빈','아이스 헤이즐넛 라떼',5600,NULL),(123,'커피빈','아이스 모카 라떼',5600,NULL),(124,'투썸플레이스','스트로베리라떼',5400,NULL),(125,'나폴레옹과자점','무화과스콘',3500,NULL),(126,'나폴레옹과자점','버터크림빵',2200,NULL),(127,'나폴레옹과자점','고소한 소금빵',2500,NULL),(128,'투썸플레이스','키위 바나나 주스',5500,NULL),(130,'투썸플레이스','라임 레몬 에이드',6300,NULL),(133,'궁전제과','공룡알빵',4500,NULL),(134,'궁전제과','나비파이',3300,NULL),(136,'궁전제과','마약빵',2500,NULL),(137,'할리스 커피','카페 모카',5200,NULL),(139,'동백양과점','딸기 수플레 팬케이크',23000,NULL),(140,'할리스 커피','디카페인 바닐라 딜라이트',4800,NULL),(141,'동백양과점','무화과 수플레 팬케이크',30000,NULL),(142,'할리스 커피','아포카토',6300,NULL),(144,'동백양과점','플레인 수플레 팬케이크',18000,NULL),(145,'김영모과자점','누룩발효빵',2100,NULL),(146,'김영모과자점','명장만쥬',3000,NULL),(147,'헤리티지클럽','부라타치즈',16000,NULL),(148,'김영모과자점','몽블랑',6500,NULL),(149,'헤리티지클럽','브리치즈구이',16000,NULL),(150,'헤리티지클럽','플레인 스콘 세트',5000,NULL),(151,'안스베이커리','깜빠뉴',6200,NULL),(152,'안스베이커리','나가사키 카스테라',3300,NULL),(153,'안스베이커리','건포도빵',3600,NULL),(154,'온','팥빙수',18000,NULL),(155,'온','가마솥빵(플레인)',20000,NULL),(156,'온','대나무잎 얼그레이 푸딩',12000,NULL),(157,'끼룩하우스','버터쿠키',3000,NULL),(158,'끼룩하우스','애플 스트러들',9500,NULL),(159,'끼룩하우스','프랄린 스트러들',9500,NULL),(160,'에그슬럿','비프패티 페어팩스',11800,NULL),(161,'에그슬럿','페어팩스',7800,NULL),(162,'에그슬럿','서울S 초이스 파머스 프리타타',6800,NULL),(163,'뜰안','뜰안 단팥죽',10000,NULL),(164,'뜰안','복분자아이스',9000,NULL),(165,'뜰안','쌍화차',8500,NULL),(166,'플리퍼스','딸기후르츠 수플레 팬케이크',20000,NULL),(167,'플리퍼스','플레인 수플레 팬케이크',16000,NULL),(168,'플리퍼스','로스트피스타치오&캐러멜넛츠',19000,NULL),(169,'퀴즈노스','트레디셔널',6700,NULL),(170,'퀴즈노스','새우야채',6900,NULL),(171,'퀴즈노스','에그마요',7600,NULL),(172,'메가커피','디카페인 아메리카노',2000,NULL),(173,'메가커피','샤인머스캣그린주스',3800,NULL),(174,'메가커피','딸기바나나주스',3500,NULL),(175,'빠숑숑','브라운 비프 샌드위치',8500,NULL),(176,'빠숑숑','엘로우 덕 샌드위치',8500,NULL),(177,'빠숑숑','화이트치킨 샌드위치',8500,NULL),(178,'풀 바셋','피스타치오 아이스크림 오트 카페라떼',6800,NULL),(182,'풀 바셋','바닐라빈 카페라떼',4800,NULL),(183,'풀 바셋','아이스 스페니쉬 카페 라떼 [연유]',5900,NULL),(184,'어게인프레쉬','아보카도 크림치즈 샌드위치',12900,NULL),(185,'빽다방','원조커피',2500,NULL),(186,'빽다방','블랙펄카페라떼',3500,NULL),(187,'빽다방','아이스크림 카페모카',4000,NULL),(188,'소금집델리','잠봉뵈르 샌드위치',14000,NULL),(189,'소금집델리','비엘티 샌드위치',15000,NULL),(190,'소금집델리','루벤 샌드위치',17000,NULL),(191,'FOURB','플레인 베이글',3000,NULL),(192,'FOURB','아더 베이글',3900,NULL),(193,'FOURB','크림치즈 베이글',3900,NULL),(194,'매머드 커피','허니베리 홍초 에이드',3000,NULL),(195,'매머드 커피','패션 오렌지 아이스티',2800,NULL),(196,'매머드 커피','토피넛 샷 라떼',2500,NULL),(197,'에브리띵 베이글','무지개 베이글',4000,NULL),(198,'에브리띵 베이글','아드보카드 베이글',13000,NULL),(199,'에브리띵 베이글','크림치즈 & 록스',13000,NULL),(200,'Sub Way','이탈리안 비엠티',9300,NULL),(201,'Sub Way','에그마요',8100,NULL),(202,'Sub Way','로스트 치킨',9900,NULL),(203,'뚜레쥬르','코코넛 라즈베리 패스트리',4000,NULL),(204,'뚜레쥬르','클래식 딸기잼 맘모스',6500,NULL),(205,'뚜레쥬르','남해마늘로 만든 버터 갈릭 꽈배기',2800,NULL);
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-21 12:50:07
